Beispieldatei fuer die Strive-Demo.
